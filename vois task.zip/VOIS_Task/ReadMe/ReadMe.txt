Script Scope / Function
-------------------------------------
Google for Vodafone and assert that google results
on 2nd page are equal to results on 3rd page .


Flow will be
------------------------------------
1) open google.com
2) search for"Vodafone"
3) scroll down
4) press on next page button
5) count search results on 2nd page
6) press on the next page button
7) count search results on 3rd page
8) assert that results on both pages are equal to each other


Steps to run the script
--------------------------------------
1) head to (RunTheScript.xml) file
2) unComment the desired driver to be run
2) right click on the file and run as TestNg suite


Steps to check screenShot on failure
--------------------------------------
1) head to Google_results_test file 
2) uncomment the commented part 
3) refresh the project
4) check the screenshot in ScreenShots folder 


Steps to check auto generated test reports
------------------------------------------
1) Head to test-output folder
2) (Detailed report) You can find this report in the <index.html> file. 
   It combines detailed information like the errors, 
   test groups, execution time, step-by-step logs and TestNG XML file
   
   (Summary report)You can see it from the <emailable-report.html> file.
   It’s an email-friendly report which you can embed and share with the stakeholders
3) right click - open with - web browser


Steps to check External test reports
---------------------------------------
1) check <ExtentReportResults.html> file
2) right click - open with - web browser

Script Owner
-----------------------------------------
Omnia Abullah