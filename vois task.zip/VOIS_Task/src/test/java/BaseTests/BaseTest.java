package BaseTests;


import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import utilities.Helper;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;




public class BaseTest 
{
	protected static WebDriver driver;
	private String chromePath = System.getProperty("user.dir")+"\\Resources\\Drivers\\chromedriver96.exe";
	private String foxPath = System.getProperty("user.dir")+"\\Resources\\Drivers\\geckodriver.exe";
	private String edgePath = System.getProperty("user.dir")+"\\Resources\\Drivers\\msedgedriver.exe";
	protected static Properties props;
	
	
	public static ExtentTest test;
	public static ExtentReports report;
	

	@BeforeTest
	@Parameters("browser")
	public void setup(String browser) throws Exception
	{
		//External Reports
		report = new ExtentReports(System.getProperty("user.dir")+"\\ExtentReportResults.html");
		test = report.startTest("ExtentDemo");
		
		//Properties
				props = System.getProperties();
				try 
				{
					props.load(new FileInputStream(new File("Resources/Inputs/StaticData.properties")));
				} 
				catch(Exception e) 
				{
					e.printStackTrace();
					System.exit(-1);
				}

				
		
		if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver",foxPath);
			driver = new FirefoxDriver();
		}

		else if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver",chromePath);
			driver = new ChromeDriver();
		}

		else if(browser.equalsIgnoreCase("Edge"))
		{
			System.setProperty("webdriver.edge.driver",edgePath);
			driver = new EdgeDriver();
		}
		else
		{
			throw new Exception("Browser is not correct");
		}
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		driver.navigate().to(props.getProperty("webURL"));
	}

	@AfterSuite
	public void close() 
	{
		driver.quit();
		
		//close report
		report.endTest(test);
		report.flush();
	}  


	//take screenshot when test case fail and add it in the screenshot folder
	@AfterMethod
	public void screenShotOnFailure(ITestResult result) 
	{
		if (result.getStatus()== ITestResult.FAILURE) 
		{
			System.out.println("Failed");
			Reporter.log("Failed");
			System.out.println("TakingScreenshot..");
			Reporter.log("Failed");
			Helper.captureScreenShot(driver,result.getName());
			
		}
	} 


}
