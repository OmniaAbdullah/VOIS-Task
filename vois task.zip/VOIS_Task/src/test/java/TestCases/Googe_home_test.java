package TestCases;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import BaseTests.BaseTest;
import Page_Bases.Google_home_page;


public class Googe_home_test extends BaseTest
{
	@Test
	private void googleHomeSearch() 
	{

		Google_home_page Google_home_page_object =  new Google_home_page(driver);

		//Assert on google title and Add results to External Report
		if(driver.getTitle().equals("Google"))
		{
			test.log(LogStatus.PASS, "Navigated to the specified URL");
		}
		else
		{
			test.log(LogStatus.FAIL, "Test Failed");
		}

		Google_home_page_object.googleSendSearchWord(props.getProperty("searchForVodafone"));



	}
}
