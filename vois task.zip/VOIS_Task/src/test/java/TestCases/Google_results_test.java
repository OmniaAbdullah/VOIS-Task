package TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import BaseTests.BaseTest;
import Page_Bases.Google_reults_page;

public class Google_results_test extends BaseTest
{
	@Test
	private void GoogleResultsTest() throws InterruptedException 
	{

		Google_reults_page google_reults_page_object = new Google_reults_page(driver);
		google_reults_page_object.scroll_Buttom_HeadToNextPage();
		Thread.sleep(1000);
		google_reults_page_object.nextBTN();	
		int countPage2 = google_reults_page_object.count(); 
		google_reults_page_object.nextBTN();
		int countPage3 = google_reults_page_object.count();



		// UnComment if u want to try ScreenShot on failure method
		// you will find the image in screen shoot folder after refresh 



		/*
		 WebElement x = driver.findElement(By.id("A"));
		 x.click();
		 */


		try 
		{
			Assert.assertSame(countPage2,countPage3);
			System.out.println("The number of results on page 2 are equal to page 3");
		}
		catch (AssertionError e) 
		{
			System.out.println("The number of results on page 2 NOT equal to page 3");
		}

	}
}