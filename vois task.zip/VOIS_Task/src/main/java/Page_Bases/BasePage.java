package Page_Bases;


import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;	

public class BasePage 
{
	protected static WebDriver driver ;
	protected static Select select;
	protected static Actions action;
	protected static Alert alert;
	protected static WebDriverWait wait;
	

	//constructor
	public BasePage(WebDriver driver) 
	{
		BasePage.driver =  driver;
		wait =  new WebDriverWait(driver, 60);
	}

	//Safe Find
	private WebElement safeFind(By locator) 
	{
		return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}


	//Click on Button
	public void clickButton(By button) 
	{
		try 
		{
			safeFind(button).click();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	//Clear Text
	public void clearText(By button) 
	{
		safeFind(button).clear();
	}

	//Send Text
	public void sendText(By TestBox , String text)
	{
		safeFind(TestBox).sendKeys(text);
	}

	//Send Text by Enter button
	public void sendTextByKey(By TestBox , Keys enter)
	{
		safeFind(TestBox).sendKeys(enter);
	}

	//Get Text
	public String getText(By element)
	{
		return safeFind(element).getText();
	}

	//ScrollToButtom
	public void ScrollToButtom()
	{
		((JavascriptExecutor) driver)
		.executeScript("window.scrollTo(0, document.body.scrollHeight)");

	}



}
