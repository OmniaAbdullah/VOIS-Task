package Page_Bases;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class Google_home_page extends BasePage
{

	//Constructor
	public Google_home_page(WebDriver driver) 
	{
		super(driver);
	}

	private static By searchBox= By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div[2]/div[2]/input");
	private static By ToEnglishBTN = By.linkText("English");
	
	
	public void googleSendSearchWord(String searchForWord) 
	{
		//open google with English language
		clickButton(ToEnglishBTN);
		//send Vodafone
		sendText(searchBox,searchForWord);
		sendTextByKey(searchBox, Keys.ENTER);
	}

	
	
	

	



}
