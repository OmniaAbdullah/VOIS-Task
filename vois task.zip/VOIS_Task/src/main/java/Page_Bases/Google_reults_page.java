package Page_Bases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Google_reults_page extends BasePage
{

	public Google_reults_page(WebDriver driver) 
	{
		super(driver);
	}

	//next page element 
	private static By nextBTN = By.linkText("Next");



	//scroll Down
	public void scroll_Buttom_HeadToNextPage()
	{
		try 
		{
			Thread.sleep(500);
			ScrollToButtom();
		} 
		catch (InterruptedException e) 
		{
			ScrollToButtom();
		}

	}


	//find all h3 elements (google results ignoring adds sections)
	public int count() 
	{
		List<WebElement> googleResults = driver.findElements(By.className("LC20lb"));
		int size1 = 0;
		for (WebElement loop : googleResults)
		{
			size1++;
		}
		return size1;
	}
	
	
	//Click on Next button
	public void nextBTN() 
	{
		clickButton(nextBTN);
	}




}
